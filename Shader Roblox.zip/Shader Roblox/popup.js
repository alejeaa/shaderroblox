document.addEventListener('DOMContentLoaded', () => {
  const specialCode = 'RTX2025';

  const keyInput = document.getElementById('keyInput');
  const claimBtn = document.getElementById('claimBtn');
  const status = document.getElementById('status');
  const rewardBox = document.getElementById('rewardBox');

  claimBtn.addEventListener('click', () => {
    const key = keyInput.value.trim();

    if (!key) {
      status.textContent = 'Please enter a code!';
      status.style.color = 'orange';
      rewardBox.style.display = 'none';
      rewardBox.style.opacity = '0';
      return;
    }

    status.textContent = '⏳ Verifying your code, please wait...';
    status.style.color = '#00bfff';
    rewardBox.style.display = 'none';
    rewardBox.style.opacity = '0';
    claimBtn.disabled = true;

    // 5 saniyelik bekleme süresi
    setTimeout(() => {
      if (key.toUpperCase() === specialCode) {
        status.textContent = '✅ Code validated! Your shader is activated!';
        status.style.color = '#32cd32';
        rewardBox.style.display = 'block';
        rewardBox.style.animation = 'fadeIn 0.25s ease forwards';
      } else {
        status.textContent = '❌ Invalid code, please try again.';
        status.style.color = 'red';
        rewardBox.style.display = 'none';
        rewardBox.style.opacity = '0';
      }
      claimBtn.disabled = false;
    }, 5000);
  });

  // Enter tuşu ile de onaylama
  keyInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      claimBtn.click();
    }
  });
});
